# PCA9635 library

Used to control this I2C led driver

## Installing

Clone this repo to your arduino libraries folder, then clone the following repos as well

  * git://github.com/rambo/I2C.git
  * git://github.com/rambo/i2c_device.git

