
Installation
copy the SED1531 folder into ..

Linux
~/sketchbook/libraries/

Mac
Documents/Arduino/libraries/

Win
My Documents\Arduino\libraries\

//Installation guide for libraries on the arduino website:
http://arduino.cc/en/Guide/Libraries

===================================================

    SED1531 (glcd driver) Arduino library
 
    This library works with arduino firmware 1.0 or higher
    2013/03/10 version 1.0 Initial release
 
    This file is part of the SED1531 Arduino library.
 
    SED1531 Arduino library Copyright (c) 2013 Tom van Zutphen
    http://www.tkkrlab.nl/wiki/Glcd_48x100

    This library is largely based on / ported from from the
    library (c) 2013 by Peter van Merkerk
    http://sourceforge.net/p/glcdsed1531lib/wiki/Home/

    I adapted it for use with Arduino and added some commands to draw circles,
    make it compatible with the arduino print command and add collision detect
    for all drawing functions except text.

    The SED1531 Arduino library is free software: you can redistribute it and/or
    modify it under the terms of the GNU General Public License as published
    by the Free Software Foundation, either version 3 of the License, or (at
    your option) any later version.

    The SED1531 Arduino library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
    Public License for more details.

    You should have received a copy of the GNU General Public License along with
    the SED1531 Arduino library If not, see http://www.gnu.org/licenses/.
 
 
